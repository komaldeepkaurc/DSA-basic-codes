// // Insertion
// #include <iostream>
// using namespace std;

// struct node {
//   int data;
//   node *left;
//   node *right;

//   node(int value) {
//     data = value;
//     left = right = nullptr;
//   }
// };

// node *insert(node *root, int data) {
//   if (root == nullptr) {
//     return new node(data);
//   }
//   if (data < root->data) {
//     root->left = insert(root->left, data);

//   } else {
//     root->right = insert(root->right, data);
//   }
//   return root;
// }

// void inorder(node *root) {
//   if (root != nullptr) {
//     inorder(root->left);
//     cout << root->data << " ";
//     inorder(root->right);
//   }
// }
// int main() {
//   node *root = nullptr;
//   int n, value;
//   cin >> n;
//   for (int i = 0; i < n; i++) {
//     cout << "Enter value to insert: ";
//     cin >> value;
//     root = insert(root, value);
//   }
//   cout<<"Inorder traversal after insertions: ";
//   inorder(root);
//   cout<<endl;
//   return 0;
// }

// // search operation
// #include<iostream>
// using namespace std;
// struct node{
// int data;
// node *left;
// node* right;

// node(int value){
//   data = value;
//   left = right = nullptr;
// }
// };

// node* insert(node* root, int data){
//   if(root==nullptr){
//     return new node(data);
//   }
//   if(data< root->data){
//     root->left = insert(root->left, data);
    
//   }else{
//     root->right = insert(root->right, data);
//   }
//   return root;
// }

// node* search(node* root, int key){
//   if(root==nullptr || root->data == key){
//     return root;
//   }
//   if(key < root->data){
//     return search(root->left, key);
//   }
  
//   return search(root->right, key);
  
// }
// int main(){
//   node *root = nullptr;
//   int n;
//   cin>>n;
//   int value;
//   for(int i=0;i<n;i++){
//     cin>>value;
//     root = insert(root, value);
   
//   }
//   int k;
//   cin>>k;
//   node *result = search(root,k);
//   if(result!= nullptr){
//     cout<<"Element found"<<endl;
//   }else{
//     cout<<"Element not found"<<endl;
//   }
//   return 0;
// }

// // Delete operation

// #include<iostream>
// using namespace std;
// struct node{
// int data;
// node *left;
// node* right;

// node(int value){
//   data = value;
//   left = right = nullptr;
// }
// };

// node* insert(node* root, int data){
//   if (root == nullptr) {
//     return new node(data);
//   }
//   if (data < root->data) {
//     root->left = insert(root->left, data);
//   } else {
//     root->right = insert(root->right, data);
//   }
//   return root;
// }


// node* findMin(node* root){
//   while(root->left != nullptr){
//     root=root->left;
//   }
//   return root;
// }

// node* deleteNode(node* root, int key){
//   if(root == nullptr){
//     return root;
//   }
//   if (key < root->data)
//     root->left = deleteNode(root->left, key);
//   else if (key > root->data)
//     root->right = deleteNode(root->right, key);
//   else{
//     if(root->left == nullptr){
//       node* temp = root->right;
//       delete root;
//       return temp;
//     }
//     else if(root->right ==nullptr){
//       node* temp = root->left;
//       delete root;
//       return temp;
//     }
//     node* temp = findMin(root->right);
//     root->data = temp->data;
//     root->right = deleteNode(root->right, temp->data);
//   }
//   return root;
// }

// void inorder(node* root){
//   if(root != nullptr){
//     inorder(root->left);
//     cout<<root->data<<" ";
//     inorder(root->right);
//   }
// }

// int main(){
//   node* root = nullptr;
//   int n;
//   cin>>n;
//   int value;
//   for(int i=0;i<n;i++){
//     cin>>value;
//     root = insert(root, value);
//   }
//   cout<<"Inorder traversal before deletion: ";
//   inorder(root);
//   // enter value to delete
//   int k;
//   cin>>k;
//   root= deleteNode(root, k);
//   cout<<"Inorder traversal after deletion";
//   inorder(root);
//   cout<<endl;

//   return 0;
// }

// // check if tree is a BST
// #include<iostream>
// using namespace std;
// struct node{
// int data;
// node* left;
// node* right;

// node(int value){
//   data = value;
//   left =right=nullptr;
// }
// };

// node* insert(node* root, int data){
//   if(root==nullptr){
//     return new node(data);
//   }
//   if(data<root->data){
//     root->left = insert(root->left, data);
//   }
//   else{
//     root->right = insert(root->right, data);
//   }
//   return root;
// }

// bool isBST(node* root, node* left =nullptr, node* right = nullptr){
//   if(root == nullptr){
//     return true;
    
//   }
//   if(left != nullptr && root->data <= left->data){
//     return false;
//   }
//   if(right != nullptr && root->data >= right->data){
//     return false;
//   }
//   return isBST(root->left,left,root ) && isBST(root->right,root,right);
// }

// int main(){
//   node* root = nullptr;
//   int n;
//   cin>>n;
//   int value;
//   for(int i=0;i<n;i++){
//     cin>>value;
//     root= insert(root, value);
//   }
//   if(isBST(root)){
//     cout<<"The tree is a BST"<<endl;
//   }else{
//     cout<<"The tree is not a BST"<<endl;
//   }
//   return 0;
// }

// // Findinh minimum and maximum value in a BST
// #include<iostream>
// using namespace std;

// struct node{
// int data;
// node* left;
// node* right;

// node(int value){
//   data = value;
//   left = right = nullptr;
// }
// };

// node* insert(node* root, int data){
//   if(root==nullptr){
//     return new node(data);
//   }
//   if(data < root->data){
//     root->left =insert(root->left, data);
//   }else{
//     root->right = insert(root->right, data);
//   }
//   return root;
// }

// node* findMin(node* root){
//   while(root!= nullptr && root->left != nullptr){
//     root = root->left;
//   }
//   return root;
// }

// node* findMax(node* root){
//   while(root!= nullptr && root->right != nullptr){
//     root= root->right;
//   }
//   return root;
// }
// int main(){
//   node* root = nullptr;
//   int n;
//   cin>>n;
//   int value;
//   for(int i=0;i<n;i++){
//     cin>>value;
//     root= insert(root, value);
//   }

//   node* minNode = findMin(root);
//   node* maxNode = findMax(root);

//   cout << "Minimum value: " << minNode->data << endl;
//   cout << "Maximum value: " << maxNode->data << endl;

//   return 0;
  
// }


// #include <iostream>
// using namespace std;

// // Node structure for the BST
// struct Node {
//     int data;
//     Node* left;
//     Node* right;

//     // Constructor to initialize a new node
//     Node(int value) {
//         data = value;
//         left = nullptr;
//         right = nullptr;
//     }
// };

// // Function to insert a node into the BST
// Node* insert(Node* root, int value) {
//     if (root == nullptr) {
//         return new Node(value);
//     }
//     if (value < root->data) {
//         root->left = insert(root->left, value);
//     } else {
//         root->right = insert(root->right, value);
//     }
//     return root;
// }

// // Function to calculate the height of the BST
// int findHeight(Node* root) {
//     if (root == nullptr) {
//         return -1; // Return -1 for height of an empty tree
//     }
//     int leftHeight = findHeight(root->left);
//     int rightHeight = findHeight(root->right);
//     return 1 + max(leftHeight, rightHeight);
// }

// // Main function
// int main() {
//     Node* root = nullptr;
//     root = insert(root, 15);
//     root = insert(root, 10);
//     root = insert(root, 20);
//     root = insert(root, 8);
//     root = insert(root, 12);
//     root = insert(root, 17);
//     root = insert(root, 25);

//     cout << "Height of the BST: " << findHeight(root) << endl;

//     return 0;
// }