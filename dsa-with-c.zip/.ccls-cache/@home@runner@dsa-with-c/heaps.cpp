// // // find kth element in a heap
// #include <iostream>
// #include <algorithm>  // For sort
// using namespace std;

// // Function to find the kth largest element using simple sorting
// int kthLargestElement(int arr[], int n, int k) {
//     // Sort the array in ascending order
//     sort(arr, arr + n);

//     // The kth largest element will be at position n - k
//     return arr[n - k];
// }

// // Usage example
// int main() {
//     int arr[] = {12, 3, 5, 7, 19};
//     int n = sizeof(arr) / sizeof(arr[0]);
//     int k = 2;

//     cout << "The " << k << "th largest element is: " << kthLargestElement(arr, n, k) << endl;  // Output: 7
//     return 0;
// }

// // insertion

// #include<iostream>
// using namespace std;

// void insert(int arr[], int &n, int x){
//     arr[n] = x;
//     int i = n;
//     n++;
//     while(i>0){
//         int parent = i-1/2;
//         if(arr[i] > arr[parent]){
//             swap(arr[parent], arr[i]);
//             i = parent;
//         }else{
//             break;
//         }
//     }
// }

// int main(){
//     int n;
//     cin>>n;
//     int arr[n];
//     for(int i=0;i<n;i++){
//         cin>>arr[i];
//     }
//     int x;
//     cin>>x;
//     insert(arr, n, x);
//     for(int i=0;i<n;i++){
//         cout<<arr[i]<<" ";
//     }
//     return 0;
// }


// // deletion krna hai bhaii
// int foldingmethod(int key,int m)
// {
// int sum=0;
// while(key>0)
// {
// sum=sum+key%100;
// key/=100;
// }
// return sum%m;
// }
// int main()
// {
// int keys[]={123,456,234};
// int m=10;
// cout<<"Key value";
// for(int key:keys)
// {

// int hashvalue=foldingmethod(key,m);
// cout<<key<<" "<<hashvalue<<endl;
// }
// return 0;
// } 
