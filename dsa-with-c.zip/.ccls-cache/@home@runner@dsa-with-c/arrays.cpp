// ARRAYS
// Insertion
// #include<iostream>
// using namespace std;
// int main(){
//     int n;
//     cin>>n;
//     int arr[n];  
//     for(int i=0;i<n;i++){
//         cin>>arr[i];
//     }
//     int element;
//     cin>>element;
//     int position;
//     cin>>position;
//     for(int i=n;i>position;i--){
//         arr[i] = arr[i-1];
//     }
//     arr[position] = element;
//     n++;
//     for(int i=0;i<n;i++){
//         cout<<arr[i]<<" ";
//     };
//     return 0;
// }

// Deletion
// #include<iostream>
// using namespace std;
// int main(){
//     int n;
//     cin>>n;
//     int arr[n];
//     for(int i=0;i<n;i++){
//         cin>>arr[i];
//     }
//     int position;
//     cin>>position;
//     for(int i=position-1;i<n-1;i++){
//         arr[i] = arr[i+1];
//     }
//     n--;
//     for(int i=0;i<n;i++){
//         cout<<arr[i]<<" ";
//     }
// }

// Sorting
// #include<iostream>
// using namespace std;
// int main(){
//     int n;
//     cin>>n;
//     int arr[n];
//     for(int i=0;i<n;i++){
//         cin>>arr[i];
//     }
//     //bubble sorting
//     for(int i=0;i<n-1;i++)
//         for(int j=i+1;j<n;j++){
//             if(arr[i]>arr[j]){
//                 int temp = arr[i];
//                 arr[i] = arr[j];
//                 arr[j] = temp;
//             }else{
//                 continue;
//             }
//         }
//     for(int i=0;i<n;i++){
//         cout<<arr[i]<<" ";
//     }
// }

// Searching

// // Linear Search
// #include<iostream>
// using namespace std;
// int main(){
//     int n;
//     cin>>n;
//     int arr[n];
//     for(int i=0;i<n;i++){
//         cin>>arr[i];
//     }
//     int element;
//     cin>>element;
//     bool found=false;
//     for(int i=0;i<n;i++){
//         if(element==arr[i]){
//             cout<<"Element found at position: "<<i+1;
//             found = true;
//             break;
//         }
//     }if(found != true){
//         cout<<"Element not found";
//     }

// }

// // Binary Search
// #include<iostream>
// using namespace std;
// int main(){
//     int n;
//     cin>>n;
//     int arr[n];
//     for(int i=0;i<n;i++){
//         cin>>arr[i];
//     }
//     int element;
//     cin>>element;
//     int low=0, high=n-1, mid;
//     mid = low + (high-low)/2;
//     while(low>=high){
//         if(arr[mid] == element){
//             cout<<mid<<" ";
//         }
//         else if(arr[mid]>element){
//             high = mid-1;
//         }
//         else{
//             low = mid+1;
//         }
//     }
// }

// // Merging
// #include<iostream>
// using namespace std;

// void mergearrays(int arr1[], m, int arr2[], n, int arr3[]){
//     int i=0, j=0, k=0;
//     while(i<m && j<<n){
//         if(arr1[i]<arr2[j]){
//             arr3[k++] = arr1[i++];
//             k++;
//         }
//         else{
//             arr3[k++] = arr2[j++];
//         }
//     }
//     while(i<m){
//         arr3[k++] = arr1[i++];
//     }
//     while(j<n){
//         arr3[k++] = arr2[j++];
//     }
// }
// int main(){
//     int m;
//     cin>>m;
//     int arr1[m];
//     for(int i=0;i<m;i++){
//         cin>>arr1[i];
//     }

//     int n;
//     int arr2[n];
//     for(int i=0;i<n;i++){
//         cin>>arr2[i];
//     }
//     int arr[m+n];
//     mergearrays(arr1, m, arr2, n, arr);

//     for(int i=0;i<m+n;i++)[
//         cout<<arr[i]<<" ";
//     ]
//     return 0;
// }
