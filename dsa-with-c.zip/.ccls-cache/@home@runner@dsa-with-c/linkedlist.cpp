// traversal in linked list

// #include<iostream>
// using namespace std;

// struct Node{
// int data;
// Node* next;
// };

// void traverse(Node* head){
//   Node* temp = head;
//   while(temp!=nullptr){
//     cout<<temp->data<<" ";
//     temp = temp->next;
//   }
//   cout<<"end"<<endl;
// }

// Node* createLinkedList(int n){
//   if(n<=0){
//     cout<<"No. of nodes should be greater than 0"<<endl;
//     return nullptr;
//   }
//   Node* head=nullptr;
//   Node* tail = nullptr;

//   cout<<"Enter the values for linked list: "<<endl;
//   for(int i=0;i<n;i++){
//     int value;
//     cin>>value;

//     Node* newNode = new Node{value,nullptr};
//     if(head == nullptr){
//       head = newNode;
//       tail = newNode;
//     }
//     else{
//       tail->next = newNode;
//       tail = newNode;
//     }
//   }
//   return head;
// }

// int main(){
//   int n;
//   cin>>n;
//   Node* head = createLinkedList(n);
//   cout<<"The linkedlist is: ";
//   traverse(head);
//   return 0;
// }


// Insertion in linked list
// #include<iostream>
// using namespace std;

// struct Node{
// int data;
// Node* next;
// };

// void traverse(Node* head){
//   Node* temp = head;
//   while(temp!=nullptr){
//     cout<<temp->data<<" ";
//     temp = temp->next;
//   }
//   cout<<"end"<<endl;
// }

// Node* createLinkedList(int n){
//   if(n<=0){
//     cout<<"No. of nodes should be greater than 0"<<endl;
//     return nullptr;
//   }
//   Node* head=nullptr;
//   Node* tail = nullptr;

//   cout<<"Enter the values for linked list: "<<endl;
//   for(int i=0;i<n;i++){
//     int value;
//     cin>>value;

//     Node* newNode = new Node{value,nullptr};
//     if(head == nullptr){
//       head = newNode;
//       tail = newNode;
//     }
//     else{
//       tail->next = newNode;
//       tail = newNode;
//     }
//   }
//   return head;
// }

// Node* insertion(Node* head, int value, int position){
//   Node* newNode = new Node{value, nullptr};
//   // if inserting at the beginning
//   if(position ==0){
//     newNode->next  =head;
//     head = newNode;
//     return head;
//   }
//   Node* temp = head;
//   // to traverse to the node just before the desired position
//   for(int i=0;i<position-1 && temp!= nullptr;i++){
//     temp = temp->next;
//   }
//   if(temp != nullptr){
//     newNode->next = temp->next;
//     temp->next = newNode;
    
//   }else{
//     cout<<"Position out of bounds!"<<endl;
//   }
//   return head;
// }

// int main(){
//   int n;
//   cin>>n;
  
//   Node* head = createLinkedList(n);
  
//   cout<<"The linkedlist is: ";
//   traverse(head);

//   // inserting now
//   int value;
//   int position;
//   cin>>position;
//   cin>>value;

//   head = insertion(head,value,position);
//   cout<<"The final linkedlist after insertion is: ";
//   traverse(head);
  
//   return 0;
// }

// DELETION IN LINKED LIST
// #include<iostream>
// using namespace std;

// struct Node{
// int data;
// Node* next;
// };

// void traverse(Node* head){
//   Node* temp = head;
//   while(temp!=nullptr){
//     cout<<temp->data<<" ";
//     temp = temp->next;
//   }
//   cout<<"end"<<endl;
// }

// Node* createLinkedList(int n){
//   if(n<=0){
//     cout<<"no. of nodes should be greater than 0"<<endl;
//     return nullptr;
    
//   }
//   Node* head =nullptr;
//   Node* tail = nullptr;
//   cout<<"enter the values for linked list: ";
//   for(int i=0;i<n;i++){
//     int value;
//     cin>>value;

//     Node* newNode = new Node{value, nullptr};
    
//     if(head==nullptr){
//       head=newNode;
//       tail=newNode;
      
//     }else{
//       tail->next = newNode;
//       tail = newNode;
//     }
//   }
//   return head;
// }


// Node* deletion(Node* head, int position){
//   if(head==nullptr){
//     cout<<"List is empty."<<endl;
//     return nullptr;
//   }
//   if(position == 1){
//     Node* temp = head;
//     head=  head->next;
//     delete temp;
//     return head;
//   }

//   Node* temp = head;

//   for(int i=0;i<position-1;i++){
//     temp = temp->next;
//   }
  
//   if(temp==nullptr || temp->next == nullptr){
//     cout<<"Position out of range"<<endl;
//     return head;
//   }
//   // delete the desired position

//   Node* nodetodelete = temp->next;
//   temp->next = temp->next->next;
//   delete nodetodelete;
//   return head;
// }

// int main(){
//   int n;
//   cin>>n;

//   Node* head = createLinkedList(n);
//   cout<<"the linked list is: ";
//   traverse(head);

//   int position;
//   cin>>position;

//   head = deletion(head, position);
//   cout<<"The linked list after deletion is: ";
//   traverse(head);

//   return 0;
// }

// doubly linked list

#include<iostream>
using namespace std;

struct Node{
int data;
Node* prev;
Node* next;
}

class DoublyLinkedList{
  public:
  Node* head;
  DoublyLinkedList(){
    head = nullptr;
    
  }

  void append(int data){
    Node* newNode = new Node{data, nullptr, nullptr};
    if(!head){
      head = newNode;
    }
    else{
      Node* temp = head;
      while(temp->next){
        temp = temp->next;
      }
      temp->next  =newNode;
      newNode->prev = temp;
    }
    
  }

  void traverseForward(){
    Node* temp = head;
    while(temp){
      cout<<temp->data<<" ";
      temp = temp->next;
    }
    cout<<endl;
  }
void traverseBackward(){
  Node* temp = head;
  if(temp){
    while(temp->next){
      temp=temp->next;
    }
    while(temp){
      cout<<temp->data<<" ";
      temp = temp->prev;
    }
  }
  cout<<endl;
  // Delete a node from the list
      void deleteNode(int data) {
          Node* temp = head;
          while (temp) {
              if (temp->data == data) {
                  if (temp->prev) {
                      temp->prev->next = temp->next;
                  }
                  if (temp->next) {
                      temp->next->prev = temp->prev;
                  }
                  if (temp == head) {
                      head = temp->next;
                  }
                  delete temp;
                  return;
              }
              temp = temp->next;
          }
      }
  };

  int main() {
      DoublyLinkedList dll;

      int n;
      cout << "Enter number of nodes: ";
      cin >> n;

      for (int i = 0; i < n; i++) {
          int value;
          cout << "Enter value for node " << i + 1 << ": ";
          cin >> value;
          dll.append(value);
      }

      cout << "Traverse Forward: ";
      dll.traverseForward();

      cout << "Traverse Backward: ";
      dll.traverseBackward();

      int deleteValue;
      cout << "Enter value to delete: ";
      cin >> deleteValue;
      dll.deleteNode(deleteValue);

      cout << "After Deletion (Forward): ";
      dll.traverseForward();

      return 0;
  }


// CIRCULAR LINKED LIST
// #include<iostream>
// using namespace std;

// struct Node {
//     int data;
//     Node* next;
// };

// class CircularLinkedList {
// public:
//     Node* head;

//     CircularLinkedList() {
//         head = nullptr;
//     }

//     // Add node at the end
//     void append(int data) {
//         Node* newNode = new Node{data, nullptr};
//         if (!head) {
//             head = newNode;
//             newNode->next = head; // point to itself, making the list circular
//         } else {
//             Node* temp = head;
//             while (temp->next != head) {
//                 temp = temp->next;
//             }
//             temp->next = newNode;
//             newNode->next = head; // last node points to head
//         }
//     }

//     // Traverse the list
//     void traverse() {
//         if (!head) return;
//         Node* temp = head;
//         do {
//             cout << temp->data << " ";
//             temp = temp->next;
//         } while (temp != head);
//         cout << endl;
//     }

//     // Delete a node from the list
//     void deleteNode(int data) {
//         if (!head) return;
//         Node* temp = head;
//         if (head->data == data) {
//             if (head->next == head) {
//                 delete head;
//                 head = nullptr;
//             } else {
//                 Node* last = head;
//                 while (last->next != head) {
//                     last = last->next;
//                 }
//                 last->next = head->next;
//                 delete head;
//                 head = last->next;
//             }
//             return;
//         }
//         while (temp->next != head && temp->next->data != data) {
//             temp = temp->next;
//         }
//         if (temp->next != head) {
//             Node* nodeToDelete = temp->next;
//             temp->next = nodeToDelete->next;
//             delete nodeToDelete;
//         }
//     }
// };

// int main() {
//     CircularLinkedList cll;

//     int n;
//     cout << "Enter number of nodes: ";
//     cin >> n;

//     for (int i = 0; i < n; i++) {
//         int value;
//         cout << "Enter value for node " << i + 1 << ": ";
//         cin >> value;
//         cll.append(value);
//     }

//     cout << "Circular Linked List: ";
//     cll.traverse();

//     int deleteValue;
//     cout << "Enter value to delete: ";
//     cin >> deleteValue;
//     cll.deleteNode(deleteValue);

//     cout << "After Deletion: ";
//     cll.traverse();

//     return 0;
// }
