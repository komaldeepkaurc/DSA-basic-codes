// CONSTRUCTORS
// #include<iostream>
// using namespace std;

// class Date{
// private:
//   int dd,mm,yy;
// public:
//   Date(): dd(31), mm(12), yy(2022){}
//   Date(int day, int month, int year){
//     if(day>=1 && day<=31){
//       dd = day;
//     }
//     else{
//       dd = 30;
//     }
//     if(month>=1 && month<=12)
//       mm = month;
//     else{
//       mm = 12;
//     }
//     if(year>=202 && year<=2998){
//       yy = year;
//     }
//     else{
//       yy=2023;
//     }
//     void display(){
//       cout<<dd<<"/"<<mm<<"/"<<yy<<endl;
//     }
//   }
// };

// int main(){
//   int day,month,year;
//   cin>>day>>month>>year;
//   Date d1;
//   d1.display();
// }

// #include<iostream>
// #include<iomanip>
// using namespace std;

// class Wall{
// private:
//   float length, height;
// public:
//   Wall(): length(0),height(0){}
//   void setData(float l, float h){
//     length = l;
//     height = h;
//   }
//   float calculateArea(){
//     return length*height;
//   }
// };

// int main(){
//   float length, height;
//   cin>>length>>height;
//   Wall wall;
//   wall.setData(length,height);
//   cout<<wall.calculateArea();
//   return 0;
// }

// #include<iostream>
// #include<iomanip>
// using namespace std;

// class Person{
// private:
//   string name;
//   int age;
// public:
//   Person(){
//     cout<<"Default constructor called"<<endl;
//   }
//   void setName(string n){
//     name = n;
//   }
//   void setAge(int a){
//     age = a;
//   }
//   void display(){
//     cout<<"Name: "<<name<<endl;
//     cout<<"Age: "<<age<<endl;
//   }
// };
// int main(){
//   string name;
//   int age;

//   getline(cin,name);
//   cin>>age;

//   Person p1;
//   p1.setName(name);
//   p1.setAge(age);
//   p1.display();
//   return 0;
// }

// #include<iostream>
// #include<iomanip>
// using namespace std;

// class Vehicle{
//   private:
//     string reg_no;
//     string make;
//     string model;
//     int year;
//   public:
//     Vehicle(string registration_number,string make, string model,int  year){
//       reg_no = registration_number;
//       this-> make = make;
//       this->model = model;
//       this-> year=year;
//     }
//   void display_details(){
//     cout<<"Registration Number: "<<reg_no<<endl;
//     cout<<"Make: "<<make<<endl;
//     cout<<"Model: "<<model<<endl;
//     cout<<"Year: "<<year<<endl;
//   }
// };
// int main(){
//   string registration_number,make,model;
//   int year;
//   getline(cin,registration_number);
//   getline(cin,make);
//   getline(cin,model);
//   cin>>year;

//   Vehicle v1(registration_number,make,model,year);
//   v1.display_details();
//   return 0;
// }

// COPY CONSTRUCTOR
// #include<iostream>
// using namespace std;

// class Distance{
// private:
//   int feet;
//   int inches;
// public:
//   // default constructor
//   Distance(): feet(0),inches(0){}
//   // parameterized constructor
//   Distance(int f, int i): feet(f), inches(i){}
//   // copy constructor
//   Distance(const Distance &d){
//     feet =d.feet;
//     inches = d.inches;
//   }
//   void setData(int f, int i){
//     feet = f;
//     inches = i;
//   }
//   Distance addDistance(const Distance &d){
//     Distance result;
//     result.feet = feet + d.feet;
//     result.inches = inches + d.inches;

//     if(result.inches >= 12){
//       result.feet += result.inches/12;
//       result.inches = result.inches%12;
//     }
//     return result;
//   }

//   void displayDistance(){
//     cout<<feet<<" feet "<<inches<<" inches"<<endl;
//   }  
// };
// int main(){
//   int f1,i1,f2,i2;
//   cin>>f1>>i1;
//   cin>>f2>>i2;
// // first distance object d1 created
//   Distance d1(f1,i1);
//   // second object created by copying 
//   Distance d2 = d1;
//   // overwriting parameters
//   d2.setData(f2,i2);
//   Distance sum = d1.addDistance(d2);
//   sum.displayDistance();
//   return 0;
// }


// #include<iostream>
// using namespace std;
// class base{
// private:
//   int x;
// public:
//   base(int n): x(n){
//     cout<<"Base Class Constructor"<<endl;
//     cout<<"Value set: "<<x<<endl;
//   }
// };
// class Initializerlist{
// private:
//   base b1;
// public:
//   Initializerlist(base b): b1(b){
//     cout<<"Initializer List Constructor"<<endl;
//   }
// };
// int main(){
// //   int n;
// //   cin>>n;
// //   Initializerlist mylist(n);
// //   return 0;
// // } 

// // #include <iostream>
// // #include <fstream>
// // using namespace std;

// // struct Employee {
// //     int id;
// //     char name[50];
// //     float salary;
// // };

// // int main() {
// //     Employee e = {101, "John Doe", 60000};

// //     // Write employee data to a binary file
// //     ofstream outFile("employee.bin", ios::binary);
// //     outFile.write((char*)&e, sizeof(e));
// //     outFile.close();

// //     // Reading from the binary file
// //     Employee e_read;
// //     ifstream inFile("employee.bin", ios::binary);
// //     inFile.read((char*)&e_read, sizeof(e_read));

// //     cout << "Employee ID: " << e_read.id << endl;
// //     cout << "Name: " << e_read.name << endl;
// //     cout << "Salary: " << e_read.salary << endl;

// //     inFile.close();
// //     return 0;
// // }



// #include<iostream>
// using namespace std;

// void insert(int arr[], int &n, int x){
//     arr[n]=x;
//     int i = n;
//     n++;
//     while(n>0){
//         int p = (i-1)/2;
//         if(arr[p]<arr[i]){
//             swap(arr[p], arr[i]);
//             i = p;
//         }
//         else{
//             break;
//         }
//     }
// }
// int main(){
//     int n;
//     cin>>n;
//     int arr[n];
//     for(int i=0;i<n;i++){
//         cin>>arr[i];
//     }
//     insert(arr,n,5);
//     for(int i=0;i<n;i++){
//         cout<<arr[i] <<" ";
//     }
// }